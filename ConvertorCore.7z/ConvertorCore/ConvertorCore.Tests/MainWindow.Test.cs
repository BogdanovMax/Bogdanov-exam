﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConvertorCore.Tests
{
    [TestClass]
    public class MainWindowTest
    {
        [TestMethod]
        public void Conv_km_ml_5give3107()
        {
            int km = 5;
            double ml = 3.1075201988812;

            MainWindow c = new MainWindow();
            double actual = c.Conv_km_ml_test(km);

            Assert.AreEqual(ml, actual);
        }
    }
}
