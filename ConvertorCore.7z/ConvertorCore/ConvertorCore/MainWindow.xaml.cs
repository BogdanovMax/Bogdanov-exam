﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;


namespace ConvertorCore
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double Result_Test = 0;

        public MainWindow()
        {
                InitializeComponent();
        }






    private void Conv_km_ml(object sender, RoutedEventArgs e)
        {
           
            double value = 1.609;
            try
            {
            double result = double.Parse(TextBox_km1.Text);
            double answer = (result / value);
                Result_Test = answer;
            string str = answer.ToString();
            if (str != "")
                {
                TextBox_ml1.Text = str;
                }
            }
            catch
            {
                
                TextBox_ml1.Text="Ошибка ввода";
            }

            
          
        }

        
        private void Conv_ml_km(object sender, RoutedEventArgs e)
        {
            double value = 1.609;
            try
            {
            double result = double.Parse(TextBox_ml2.Text);
            double answer = (result * value);
            string str = answer.ToString();
            if (str != "")
                {
                TextBox_km2.Text = str;
                }
            }
            catch
            {
                TextBox_km2.Text="Ошибка ввода";
            }
}


        private void Conv_ra_gr(object sender, RoutedEventArgs e)
        {

            double pi = 3.14159265358979323846264;
            int degree = 180;

            try
            {
            double  result = double.Parse(TextBox_ra3.Text);
            double answer = (result * degree)/ pi ;
            string str = answer.ToString();
            if (str != "")
                {
                TextBox_gr3.Text = str;
                }
            }
            catch
            {
                TextBox_gr3.Text="Ошибка ввода";
            }
        }

        private void Conv_gr_ra(object sender, RoutedEventArgs e)
        {

            double pi = 3.14159265358979323846264;
            int degree = 180;

            try
            {
                double result = double.Parse(TextBox_gr4.Text);
                double answer = 0;
                answer = (result * pi);
                answer = answer / degree;
                string str = answer.ToString();
                if (str != "")
                {
                    TextBox_ra4.Text = str;
                }
            }
            catch
            {
                TextBox_ra4.Text = "Ошибка ввода";
            }
        }
        public void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.Text = string.Empty;
            tb.GotFocus -= TextBox_GotFocus;
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9,0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        public double Conv_km_ml_test(int a)
        {
            RoutedEventArgs e = new RoutedEventArgs();
    
            Conv_km_ml(a,e);
            return Result_Test;
            throw new NotImplementedException();
        }
    }
}
